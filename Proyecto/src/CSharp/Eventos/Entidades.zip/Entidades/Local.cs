namespace Eventos.Entidades;

public class Local
{
    public int idLocal { get; set; }
    public required string Nombre { get; set; }
    public string Ubicacion { get; set; }

    public Local(int idLocal, string Nombre, string Ubicacion)
    {
        this.idLocal = idLocal;
        this.Nombre = Nombre;
        this.Ubicacion = Ubicacion;
    }
}
