namespace Eventos.Entidades;

public class Cliente
{
    public int DNI { get; set; }
    public required string nombreCompleto { get; set; }
    public required string Email { get; set; }
    public int Telefono { get; set; }
    public string Contrasena { get; set; }

    public Cliente(int DNI, string nombreCompleto, string Email, int Telefono, string Contrasena)
    {
        this.DNI = DNI;
        this.nombreCompleto = nombreCompleto;
        this.Email = Email;
        this.Telefono = Telefono;
        this.Contrasena = Contrasena;
    }
}
