namespace Eventos.Entidades;

public class QR
{
    public string url { get; set; }
    public QR()
    {
        
    }
}
